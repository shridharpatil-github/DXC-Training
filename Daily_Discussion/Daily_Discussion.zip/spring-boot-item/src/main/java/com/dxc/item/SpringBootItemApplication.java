package com.dxc.item;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootItemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootItemApplication.class, args);
	}

}
