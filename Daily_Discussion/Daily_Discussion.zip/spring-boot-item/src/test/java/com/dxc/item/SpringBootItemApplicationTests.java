package com.dxc.item;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootItemApplicationTests {

	@Test
	void contextLoads() {
	}

}
